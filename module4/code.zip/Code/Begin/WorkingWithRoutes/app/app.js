(function() {
    
    var app = angular.module('customersApp', []);
    
}());